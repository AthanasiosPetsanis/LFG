# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "LFG",
    "author" : "Thanos", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import numpy as np
import os, sys
import bpy, bmesh


addon_keymaps = {}
_icons = None
class SNA_OT_Pile_Operator_74561(bpy.types.Operator):
    bl_idname = "sna.pile_operator_74561"
    bl_label = "Pile_Operator"
    bl_description = "Produces a pile of wast"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import random
        import math
        import argparse
        # Apply transformations of all Piles

        def apply_transforms():
            # Find collections that start with "Pile_Objects"
            matching_collections = [coll for coll in bpy.data.collections if coll.name.startswith("Pile_Objects")]
            # Check if 'Pile_Objects' exists in bpy.data.collections
            if matching_collections:
                for pile_collection in matching_collections:
                    # Select all objects in the collection
                    for obj in pile_collection.objects:
                        obj.select_set(True)
                    bpy.ops.object.visual_transform_apply()
        # ----- MAIN CODE STARTS ------
        # Apply transformations for previous piles before creating a new one
        apply_transforms()
        # ----- APPEND ALL THE COLLECTIONS -----
        # Get path/names
        collection_layers = bpy.data.scenes["Scene"].view_layers['ViewLayer'].layer_collection.children
        collection_file = 'C:/Users/thano/Documents/Work/Perivallon/T3.3/Papers/Landfills_Generator_Paper/Blender/3D_models/Objects/collection.blend' # replace with proper collection path
        collection_names = ['Plastics', 'Tyres', 'Metals', 'Woods'] # replace with proper collection name(s)
        selected_collection = 'Woods'
        bpy.context.scene.frame_set(1)
        # Find and append collections one by one
        filepath = os.path.abspath(collection_file)
        for i in range(len(collection_names)):
            if collection_names[i] not in collection_layers:
                bpy.ops.wm.append(
                    filepath=filepath,
                    # directory=filepath,
                    directory=os.path.join(filepath, 'Collection'),
                    filename=collection_names[i]
                )
                # Hide render and viewport
                collection = bpy.data.collections.get(collection_names[i])
                collection.hide_render = True
                collection.hide_viewport = False  
        # Link with scene_collection and unlink from current collection 
        scene_collection = bpy.context.scene.collection
        for collection in bpy.data.collections:
            for child in collection.children:
                if child.name in collection_names:
                    scene_collection.children.link(bpy.data.collections[child.name])
                    collection.children.unlink(child)
        # ----- CREAT THE EMITTER -----
        # Create a new cone
        bpy.ops.mesh.primitive_cone_add(vertices=32, radius1=7, depth=23)
        # You can adjust the cone's properties, such as location, rotation, and scale
        pile = bpy.data.objects.get("Cone")
        pile.name = "Pile"
        pile.location = (0, 0, 20)
        pile.rotation_euler = (0, 0, 0)
        pile.scale = (1, 1, 1)
        # Add particle system to the active object (to the pile)
        particle_system = pile.modifiers.new(name="PileParticleSystem", type='PARTICLE_SYSTEM')
        # Make pile invisible (and particles visible)
        bpy.data.objects["Pile"].show_instancer_for_viewport = False
        bpy.data.objects["Pile"].show_instancer_for_render = False
        particle_settings = bpy.data.particles.new(name="PileParticleSettings")
        particle_name = particle_settings.name
        bpy.data.particles[particle_name].emit_from = 'VOLUME'
        bpy.data.particles[particle_name].frame_end = 1
        bpy.data.objects["Pile"].particle_systems["PileParticleSystem"].seed = random.randint(1,1000)
        bpy.data.particles[particle_name].distribution = 'GRID'
        bpy.data.particles[particle_name].grid_resolution = 13
        bpy.data.particles[particle_name].grid_random = 1
        bpy.data.particles[particle_name].use_rotations = True
        bpy.data.particles[particle_name].rotation_factor_random = 0.5
        bpy.data.particles[particle_name].phase_factor_random = 0.5
        bpy.data.particles[particle_name].render_type = "COLLECTION"
        bpy.data.particles[particle_name].particle_size = 1
        bpy.data.particles[particle_name].size_random = 0.25
        bpy.data.particles[particle_name].use_collection_pick_random = True
        bpy.data.particles[particle_name].instance_collection = bpy.data.collections.get(selected_collection)
        # Assign the particle settings to the particle system
        particle_system.particle_system.settings = particle_settings
        # ----- INSTANTIATE OBJECTS -----
        # Create a new collection
        # collection_layers = bpy.data.scenes["Scene"].view_layers['ViewLayer'].layer_collection.children
        # if 'Pile_Objects' not in collection_layers:
        pile_collection = bpy.data.collections.new('Pile_Objects')
        # # Link the new collection to the scene's collection hierarchy
        scene = bpy.context.scene
        scene.collection.children.link(pile_collection)
        # Get the object named "Pile"
        pile = bpy.data.objects.get('Pile')
        bpy.ops.object.duplicates_make_real()
        objs = bpy.context.selected_objects
        # Loop through all objects
        for obj in objs:
            # Loop through all collections the obj is linked to
            for coll in obj.users_collection:
                # Unlink the object
                coll.objects.unlink(obj)
            # Link each object to the target collection
            pile_collection.objects.link(obj)
        bpy.data.objects.remove(pile, do_unlink=True)
        # Set the first object as the active object
        first_object = pile_collection.objects[0]
        bpy.context.view_layer.objects.active = first_object
        # Include all objects in the RigidBodyWorld collection
        bpy.ops.object.collection_link(collection='RigidBodyWorld')
        bpy.ops.rigidbody.objects_add(type='ACTIVE')
        bpy.ops.rigidbody.object_settings_copy()
        # Exclude them from view layer
        collection_layers = bpy.data.scenes["Scene"].view_layers['ViewLayer'].layer_collection.children
        for child in collection_layers:
            if child.name in collection_names:
                child.exclude = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Joinobjects_Operator_37B28(bpy.types.Operator):
    bl_idname = "sna.joinobjects_operator_37b28"
    bl_label = "JoinObjects_Operator"
    bl_description = "Joins the objects into a single landfill"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # ----- MAIN CODE STARTS ------
        # Check if the 'Landscape' object exists in the scene
        landscape_obj = bpy.context.scene.objects.get('Landscape')
        if bpy.context.selected_objects and landscape_obj:
            # Select the 'Landscape' object
            bpy.context.view_layer.objects.active = landscape_obj
            landscape_obj.select_set(True)
            # Join selected objects with the 'Landscape' object
            bpy.ops.object.join()
            print("Selected objects joined with 'Landscape'.")
        else:
            print("No objects selected or 'Landscape' object not found.")
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Applytransformations_Operator_68490(bpy.types.Operator):
    bl_idname = "sna.applytransformations_operator_68490"
    bl_label = "ApplyTransformations_Operator"
    bl_description = "Applies the transformations of the landfill"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # ----- MAIN CODE STARTS ------
        # Find collections that start with "Pile_Objects"
        matching_collections = [coll for coll in bpy.data.collections if coll.name.startswith("Pile_Objects")]
        # Check if 'Pile_Objects' exists in bpy.data.collections
        if matching_collections:
            for pile_collection in matching_collections:
                # Select all objects in the collection
                for obj in pile_collection.objects:
                    obj.select_set(True)
                # Apply all transformations
                bpy.ops.object.visual_transform_apply()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_LFG_F3738(bpy.types.Panel):
    bl_label = 'LFG'
    bl_idname = 'SNA_PT_LFG_F3738'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'LFG'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.operator_4b2fb', text='Create Landscape', icon_value=291, emboss=True, depress=False)
        op = layout.operator('sna.pile_operator_74561', text='Create Pile', icon_value=305, emboss=True, depress=False)
        op = layout.operator('sna.applytransformations_operator_68490', text='Apply Transformations', icon_value=36, emboss=True, depress=False)
        op = layout.operator('sna.joinobjects_operator_37b28', text='Join Objects', icon_value=31, emboss=True, depress=False)
        op = layout.operator('sna.operator001_c3e8d', text='Estimate Volume', icon_value=289, emboss=True, depress=False)


class SNA_OT_Operator_4B2Fb(bpy.types.Operator):
    bl_idname = "sna.operator_4b2fb"
    bl_label = "Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import random
        import math
        import argparse

        def prune_suffix(suffix="Landscape", from_='objects'):
            # Prune suffix of Blender objects
            if from_=='objects':
                # Get all the objects in the scene
                objects = bpy.data.objects
                # Iterate through each object
                for obj in objects:
                    # Check if the object name starts with "Landscape"
                    if obj.name.startswith(suffix):
                        # Split the object name by "." and keep the first part (remove the suffix)
                        new_name = obj.name.split(".")[0]
                        # Assign the new name to the object
                        obj.name = new_name
            # Prune suffix of file names inside specified folder
            elif os.path.exists(from_) and os.path.isdir(from_):
                # Iterate through files in the directory
                for filename in os.listdir(from_):
                    base_name, file_extension = os.path.splitext(filename)
                    if base_name.endswith(suffix):
                        # Create the new filename without the suffix
                        new_filename = os.path.join(from_, base_name[:-len(suffix)] + file_extension)
                        # Rename the file
                        os.rename(os.path.join(from_,filename), new_filename)

        def apply_landscape_texture(texture_file='random'):
            '''
            This function creates a new material and creates the geometry nodes needed inside that material
            Inputs:
                texture_file:  Either 'random' or the name of the folder containing the texture, e.g. 'aerial_grass_rock'
            '''
            # Create a new material
            obj = bpy.data.objects.get("Landscape")
            material = bpy.data.materials.new(name="Landscape_material")
            obj.data.materials.append(material)
            # Switch to node editor and use nodes
            bpy.context.scene.render.engine = 'CYCLES'
            material.use_nodes = True
            tree = material.node_tree
            nodes = tree.nodes
            links = tree.links
            # Access Principled BSDF and Material Output node
            for node in tree.nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        principled_bsdf = node
                    elif node.type == 'OUTPUT_MATERIAL':
                        material_output = node
        # ----- Create Nodes -----
            # Create Normal Map node
            normal_map = nodes.new(type='ShaderNodeNormalMap')
            normal_map.location = (-250, 0)  # Set node location
            # Create Displacement node
            displacement = nodes.new(type='ShaderNodeDisplacement')
            displacement.location = (-250, -150)  # Set node location
            # Create Texture nodes (Base Color, Roughness, Normal, Displacement)
            base_color = nodes.new(type='ShaderNodeTexImage')
            base_color.location = (-700, 300)  # Set node location
            base_color.label = "Base Color"
            roughness = nodes.new(type='ShaderNodeTexImage')
            roughness.location = (-700, 100)  # Set node location
            roughness.label = "Roughness"
            normal = nodes.new(type='ShaderNodeTexImage')
            normal.location = (-700, -100)  # Set node location
            normal.label = "Normal"
            displacement_tex = nodes.new(type='ShaderNodeTexImage')
            displacement_tex.location = (-700, -300)  # Set node location
            displacement_tex.label = "Displacement"
            # Create Texture Coordinate and Mapping nodes
            texture_coordinate = nodes.new(type='ShaderNodeTexCoord')
            texture_coordinate.location = (-1200, 150)  # Set node location
            mapping = nodes.new(type='ShaderNodeMapping')
            mapping.location = (-1000, 150)  # Set node location
        # ----- Connect Nodes -----
            links.new(texture_coordinate.outputs['UV'], mapping.inputs['Vector'])
            links.new(mapping.outputs['Vector'], base_color.inputs['Vector'])
            links.new(mapping.outputs['Vector'], roughness.inputs['Vector'])
            links.new(mapping.outputs['Vector'], normal.inputs['Vector'])
            links.new(mapping.outputs['Vector'], displacement_tex.inputs['Vector'])
            links.new(base_color.outputs['Color'], principled_bsdf.inputs['Base Color'])
            links.new(roughness.outputs['Color'], principled_bsdf.inputs['Roughness'])
            links.new(normal.outputs['Color'], normal_map.inputs['Color'])
            links.new(displacement_tex.outputs['Color'], displacement.inputs['Height'])
            links.new(normal_map.outputs['Normal'], principled_bsdf.inputs['Normal'])
            links.new(displacement.outputs['Displacement'], material_output.inputs['Displacement'])
            # Create frame for Texture Coordinate and Mapping nodes
            frame_mapping = nodes.new(type='NodeFrame')
            frame_mapping.label = 'Mapping'
            frame_mapping.location = (-1300,150)
            # Add Texture Coordinate and Mapping nodes to the frame
            for node in [texture_coordinate, mapping]:
                node.parent = frame_mapping
            # Create a frame for texture nodes
            frame_textures = nodes.new(type='NodeFrame')
            frame_textures.label = 'Textures'
            frame_textures.location = (-900,200)
            # Add nodes to the frame
            for node in [base_color, roughness, displacement_tex]:
                node.parent = frame_textures
            print("Node setup created for 'Landscape'")
        # ----- Load Textures -----
            # Set the texture folder path
            folder_path = "C:/Users/thano/Documents/Work/Perivallon/T3.3/Papers/Landfills_Generator_Paper/Blender/assets/images/Ground_Textures"  # Replace with the actual folder path
            prune_suffix(suffix='_4k.blend', from_=folder_path)
            # List all files in the folder with a .jpg extension (you can modify this for other image formats)
            texture_files = [f for f in os.listdir(folder_path)]
            # Select a random image file
            if texture_files:
                if (texture_file=='random'):
                    terrain_name = random.choice(texture_files)
                    texture_file = terrain_name + '/textures'
            # Combine folder path and selected image file
            textures_path = os.path.join(folder_path, texture_file)
            prune_suffix(suffix='_4k', from_=textures_path)
            # Load textures
            for filename in os.listdir(textures_path):
                base_name, file_extension = os.path.splitext(filename)
                if base_name.endswith('_diff'):
                    base_color.image = bpy.data.images.load(textures_path + '/' + terrain_name + '_diff' + file_extension)
                elif base_name.endswith('_rough'):
                    roughness.image = bpy.data.images.load(textures_path + '/' + terrain_name + '_rough' + file_extension)
                elif base_name.endswith('_nor_gl'):
                    normal.image = bpy.data.images.load(textures_path + '/' + terrain_name + '_nor_gl' + file_extension)
                elif base_name.endswith('_nor_gl'):
                    displacement_tex.image = bpy.data.images.load(textures_path + '/' + terrain_name + '_disp' + file_extension)
                else:
                    print(f'Not needed file named: {filename} detected') 
        # ----- MAIN CODE STARTS -----
        # # Show addons
        # for addon in bpy.context.preferences.addons:
        #     print(addon.module)
        # You must have enabled the A.N.T. Lanscape addon
        # ----- CREATE LANDFILL WITH DEFINED PROPERTIES -----
        # First invoke Landscape
        bpy.ops.mesh.landscape_add('INVOKE_DEFAULT')
        prune_suffix()
        landscape_name = "Landscape"
        landscape_object = bpy.data.objects[landscape_name]
        landscape_object.ant_landscape.subdivision_x = 150
        landscape_object.ant_landscape.subdivision_y = 150
        landscape_object.ant_landscape.mesh_size_x = 80
        landscape_object.ant_landscape.mesh_size_y = 40
        landscape_object.ant_landscape.noise_size_x = 10
        landscape_object.ant_landscape.noise_size_y = 10
        landscape_object.ant_landscape.noise_size = 1.5
        landscape_object.ant_landscape.random_seed = random.randint(1,1000)
        landscape_object.ant_landscape.height = 3
        landscape_object.ant_landscape.maximum = 5
        landscape_object.ant_landscape.minimum = -2
        landscape_object.ant_landscape.edge_level = 0.5
        landscape_object.ant_landscape.falloff_x = 10
        landscape_object.ant_landscape.falloff_y = 10
        landscape_object.ant_landscape.strata_type = '1'
        landscape_object.ant_landscape.strata = 10
        # Regenerate landfill but with desired values this time
        bpy.ops.mesh.ant_landscape_regenerate('INVOKE_DEFAULT')
        prune_suffix()
        # Name changed because of regeneration
        landscape_name = "Landscape"
        landscape_object = bpy.data.objects[landscape_name]
        collection = bpy.data.collections.get("Collection")
        # Move Landscape inside Collection
        for coll in landscape_object.users_collection:
            coll.objects.unlink(landscape_object)
        collection.objects.link(landscape_object)
        # ----- ADD MATERIAL TO LANDSCAPE -----
        apply_landscape_texture()
        # Create UV map using Smart UV Project
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.uv.smart_project(angle_limit=75.0, margin_method='SCALED', island_margin=0.0, area_weight=0.0, correct_aspect=True, scale_to_bounds=True)
        bpy.ops.object.mode_set(mode='OBJECT')
        print("UV map created using Smart UV Project for the object 'Landscape'")
        landscape_object.ant_landscape.land_material = 'Landscape_material'
        # ----- ADD RIGID BODY TO LANDSCAPE -----
        # Select the object
        bpy.context.view_layer.objects.active = landscape_object
        landscape_object.select_set(True)
        # Switch to Object Mode
        bpy.ops.object.mode_set(mode='OBJECT')
        # Add a Rigid Body
        bpy.ops.rigidbody.object_add()
        # Set Rigid Body Type to Passive
        landscape_object.rigid_body.type = 'PASSIVE'
        # Set Friction to 1
        landscape_object.rigid_body.friction = 1.0
        # Set Shape to Mesh
        landscape_object.rigid_body.collision_shape = 'MESH'   
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator001_C3E8D(bpy.types.Operator):
    bl_idname = "sna.operator001_c3e8d"
    bl_label = "Operator.001"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):

        def clean_float(value: float, precision: int = 0) -> str:
            # Avoid scientific notation and strip trailing zeros: 0.000 -> 0.0
            text = f"{value:.{precision}f}"
            index = text.rfind(".")
            if index != -1:
                index += 2
                head, tail = text[:index], text[index:]
                tail = tail.rstrip("0")
                text = head + tail
            return text

        def get_unit(unit_system: str, unit: str):
            # Returns unit length relative to meter and unit symbol
            units = {
                "METRIC": {
                    "KILOMETERS": (1000.0, "km"),
                    "METERS": (1.0, "m"),
                    "CENTIMETERS": (0.01, "cm"),
                    "MILLIMETERS": (0.001, "mm"),
                    "MICROMETERS": (0.000001, "µm"),
                },
                "IMPERIAL": {
                    "MILES": (1609.344, "mi"),
                    "FEET": (0.3048, "\'"),
                    "INCHES": (0.0254, "\""),
                    "THOU": (0.0000254, "thou"),
                },
            }
            try:
                return units[unit_system][unit]
            except KeyError:
                fallback_unit = "CENTIMETERS" if unit_system == "METRIC" else "INCHES"
                return units[unit_system][fallback_unit]

        def bmesh_copy_from_object(obj, transform=True, triangulate=True, apply_modifiers=False):
            """Returns a transformed, triangulated copy of the mesh"""
            assert obj.type == 'MESH'
            if apply_modifiers and obj.modifiers:
                depsgraph = bpy.context.evaluated_depsgraph_get()
                obj_eval = obj.evaluated_get(depsgraph)
                me = obj_eval.to_mesh()
                bm = bmesh.new()
                bm.from_mesh(me)
                obj_eval.to_mesh_clear()
            else:
                me = obj.data
                if obj.mode == 'EDIT':
                    bm_orig = bmesh.from_edit_mesh(me)
                    bm = bm_orig.copy()
                else:
                    bm = bmesh.new()
                    bm.from_mesh(me)
            if transform:
                matrix = obj.matrix_world.copy()
                if not matrix.is_identity:
                    bm.transform(matrix)
                    # Update normals if the matrix has no rotation.
                    matrix.translation.zero()
                    if not matrix.is_identity:
                        bm.normal_update()
            if triangulate:
                bmesh.ops.triangulate(bm, faces=bm.faces)
            return bm

        def Method1():
            obj = bpy.context.active_object
            me = obj.data
            bm = bmesh.new()
            bm.from_mesh(me)
            bm.transform(obj.matrix_world)
            bmesh.ops.triangulate(bm, faces=bm.faces)
            volume = 0
            for f in bm.faces:
                v1 = f.verts[0].co
                v2 = f.verts[1].co
                v3 = f.verts[2].co
                volume += v1.dot(v2.cross(v3)) / 6
            print("Volume:", volume)
            bm.free()

        def Method2():
            scene = bpy.context.scene
            unit = scene.unit_settings
            scale = 1.0 if unit.system == 'NONE' else unit.scale_length
            obj = bpy.context.active_object
            bm = bmesh_copy_from_object(obj, apply_modifiers=True)
            volume = bm.calc_volume()
            bm.free()
            if unit.system == 'NONE':
                volume_fmt = clean_float(volume, 8)
            else:
                length, symbol = get_unit(unit.system, unit.length_unit)
                volume_unit = volume * (scale ** 3.0) / (length ** 3.0)
                volume_str = clean_float(volume_unit, 4)
                volume_fmt = f"{volume_str} {symbol}"
            return volume_unit
        # ----- MAIN CODE STARTS ------
        # Find collections that start with "Pile_Objects"
        matching_collections = [coll for coll in bpy.data.collections if coll.name.startswith("Pile_Objects")]
        pile_volume = [0] * matching_collections.__len__()
        # Check if 'Pile_Objects' exists in bpy.data.collections
        if matching_collections:
            for idx, pile_collection in enumerate(matching_collections):
                # Select all objects in the collection
                for obj in pile_collection.objects:
                    bpy.context.view_layer.objects.active = obj
                # Add up all volumes for each object
                    volume = Method2()
                    pile_volume[idx] += volume
        print(pile_volume)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Pile_Operator_74561)
    bpy.utils.register_class(SNA_OT_Joinobjects_Operator_37B28)
    bpy.utils.register_class(SNA_OT_Applytransformations_Operator_68490)
    bpy.utils.register_class(SNA_PT_LFG_F3738)
    bpy.utils.register_class(SNA_OT_Operator_4B2Fb)
    bpy.utils.register_class(SNA_OT_Operator001_C3E8D)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Pile_Operator_74561)
    bpy.utils.unregister_class(SNA_OT_Joinobjects_Operator_37B28)
    bpy.utils.unregister_class(SNA_OT_Applytransformations_Operator_68490)
    bpy.utils.unregister_class(SNA_PT_LFG_F3738)
    bpy.utils.unregister_class(SNA_OT_Operator_4B2Fb)
    bpy.utils.unregister_class(SNA_OT_Operator001_C3E8D)
