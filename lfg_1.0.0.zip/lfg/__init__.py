# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "LFG",
    "author" : "ThanosPetsanis", 
    "description" : "LFG makes it easy to generate realistic landfills",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os
from bpy_extras.io_utils import ImportHelper, ExportHelper
import bpy, bmesh
import bpy, os
import numpy as np
import os, sys


addon_keymaps = {}
_icons = None
lfg = {'sna_volume_var': [], }
class SNA_PT_LFG_F666D(bpy.types.Panel):
    bl_label = 'LFG'
    bl_idname = 'SNA_PT_LFG_F666D'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'LFG'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_DE2D3 = layout.box()
        box_DE2D3.alert = False
        box_DE2D3.enabled = True
        box_DE2D3.active = True
        box_DE2D3.use_property_split = False
        box_DE2D3.use_property_decorate = False
        box_DE2D3.alignment = 'Center'.upper()
        box_DE2D3.scale_x = 2.0
        box_DE2D3.scale_y = 0.800000011920929
        if not True: box_DE2D3.operator_context = "EXEC_DEFAULT"
        box_DE2D3.label(text='Add main path:', icon_value=0)
        row_E9A69 = box_DE2D3.row(heading='', align=False)
        row_E9A69.alert = False
        row_E9A69.enabled = True
        row_E9A69.active = True
        row_E9A69.use_property_split = False
        row_E9A69.use_property_decorate = False
        row_E9A69.scale_x = 1.0
        row_E9A69.scale_y = 1.0
        row_E9A69.alignment = 'Expand'.upper()
        row_E9A69.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_E9A69.prop(bpy.context.scene, 'sna_path_input', text='', icon_value=0, emboss=True)
        op = row_E9A69.operator('sna.accept_576d4', text='', icon_value=108, emboss=True, depress=False)
        box_C8800 = layout.box()
        box_C8800.alert = False
        box_C8800.enabled = True
        box_C8800.active = True
        box_C8800.use_property_split = False
        box_C8800.use_property_decorate = False
        box_C8800.alignment = 'Expand'.upper()
        box_C8800.scale_x = 1.0
        box_C8800.scale_y = 1.0
        if not True: box_C8800.operator_context = "EXEC_DEFAULT"
        box_C8800.label(text='Landscape Parameters:', icon_value=0)
        col_33AD2 = box_C8800.column(heading='', align=False)
        col_33AD2.alert = False
        col_33AD2.enabled = True
        col_33AD2.active = True
        col_33AD2.use_property_split = False
        col_33AD2.use_property_decorate = False
        col_33AD2.scale_x = 1.0
        col_33AD2.scale_y = 1.0
        col_33AD2.alignment = 'Expand'.upper()
        col_33AD2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_EA2C5 = col_33AD2.row(heading='', align=False)
        row_EA2C5.alert = False
        row_EA2C5.enabled = True
        row_EA2C5.active = True
        row_EA2C5.use_property_split = False
        row_EA2C5.use_property_decorate = False
        row_EA2C5.scale_x = 1.0
        row_EA2C5.scale_y = 1.0
        row_EA2C5.alignment = 'Expand'.upper()
        row_EA2C5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_EA2C5.label(text='Width:', icon_value=0)
        row_EA2C5.prop(bpy.context.scene, 'sna_ls_width', text='', icon_value=0, emboss=True)
        row_1B444 = col_33AD2.row(heading='', align=False)
        row_1B444.alert = False
        row_1B444.enabled = True
        row_1B444.active = True
        row_1B444.use_property_split = False
        row_1B444.use_property_decorate = False
        row_1B444.scale_x = 1.0
        row_1B444.scale_y = 1.0
        row_1B444.alignment = 'Expand'.upper()
        row_1B444.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_1B444.label(text='Length:', icon_value=0)
        row_1B444.prop(bpy.context.scene, 'sna_ls_length', text='', icon_value=0, emboss=True)
        row_E7F37 = col_33AD2.row(heading='', align=False)
        row_E7F37.alert = False
        row_E7F37.enabled = True
        row_E7F37.active = True
        row_E7F37.use_property_split = False
        row_E7F37.use_property_decorate = False
        row_E7F37.scale_x = 1.0
        row_E7F37.scale_y = 1.0
        row_E7F37.alignment = 'Expand'.upper()
        row_E7F37.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_E7F37.label(text='Height:', icon_value=0)
        row_E7F37.prop(bpy.context.scene, 'sna_ls_height', text='', icon_value=0, emboss=True)
        row_877C6 = col_33AD2.row(heading='', align=False)
        row_877C6.alert = False
        row_877C6.enabled = True
        row_877C6.active = True
        row_877C6.use_property_split = False
        row_877C6.use_property_decorate = False
        row_877C6.scale_x = 1.0
        row_877C6.scale_y = 1.0
        row_877C6.alignment = 'Expand'.upper()
        row_877C6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_877C6.label(text='Max Height:', icon_value=0)
        row_877C6.prop(bpy.context.scene, 'sna_ls_maxheight', text='', icon_value=0, emboss=True)
        row_FE3EF = col_33AD2.row(heading='', align=False)
        row_FE3EF.alert = False
        row_FE3EF.enabled = True
        row_FE3EF.active = True
        row_FE3EF.use_property_split = False
        row_FE3EF.use_property_decorate = False
        row_FE3EF.scale_x = 1.0
        row_FE3EF.scale_y = 1.0
        row_FE3EF.alignment = 'Expand'.upper()
        row_FE3EF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_FE3EF.label(text='Min Height:', icon_value=0)
        row_FE3EF.prop(bpy.context.scene, 'sna_ls_minheight', text='', icon_value=0, emboss=True)
        row_3CD35 = col_33AD2.row(heading='', align=False)
        row_3CD35.alert = False
        row_3CD35.enabled = True
        row_3CD35.active = True
        row_3CD35.use_property_split = False
        row_3CD35.use_property_decorate = False
        row_3CD35.scale_x = 1.0
        row_3CD35.scale_y = 1.0
        row_3CD35.alignment = 'Expand'.upper()
        row_3CD35.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_3CD35.label(text='Texture:', icon_value=0)
        row_3CD35.prop(bpy.context.scene, 'sna_ls_texture', text='', icon_value=0, emboss=True)
        op = box_C8800.operator('sna.landscape_operator_4b2fb', text='Create Landscape', icon_value=291, emboss=True, depress=False)
        row_0E807 = box_C8800.row(heading='', align=True)
        row_0E807.alert = False
        row_0E807.enabled = True
        row_0E807.active = True
        row_0E807.use_property_split = False
        row_0E807.use_property_decorate = False
        row_0E807.scale_x = 1.0
        row_0E807.scale_y = 1.0
        row_0E807.alignment = 'Right'.upper()
        row_0E807.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_0E807.operator('sna.load_op_d7d67', text='Load Landscape:', icon_value=0, emboss=True, depress=False)
        row_0E807.prop(bpy.context.scene, 'sna_scanned_landscapes', text='', icon_value=0, emboss=True)
        box_CC4D2 = layout.box()
        box_CC4D2.alert = False
        box_CC4D2.enabled = True
        box_CC4D2.active = True
        box_CC4D2.use_property_split = False
        box_CC4D2.use_property_decorate = False
        box_CC4D2.alignment = 'Expand'.upper()
        box_CC4D2.scale_x = 1.0
        box_CC4D2.scale_y = 1.0
        if not True: box_CC4D2.operator_context = "EXEC_DEFAULT"
        box_CC4D2.label(text='Pile Parameters:', icon_value=0)
        col_C8797 = box_CC4D2.column(heading='', align=False)
        col_C8797.alert = False
        col_C8797.enabled = True
        col_C8797.active = True
        col_C8797.use_property_split = False
        col_C8797.use_property_decorate = False
        col_C8797.scale_x = 1.0
        col_C8797.scale_y = 1.0
        col_C8797.alignment = 'Expand'.upper()
        col_C8797.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_891A7 = col_C8797.row(heading='', align=False)
        row_891A7.alert = False
        row_891A7.enabled = True
        row_891A7.active = True
        row_891A7.use_property_split = False
        row_891A7.use_property_decorate = False
        row_891A7.scale_x = 1.0
        row_891A7.scale_y = 1.0
        row_891A7.alignment = 'Expand'.upper()
        row_891A7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_891A7.label(text='Radius:', icon_value=0)
        row_891A7.prop(bpy.context.scene, 'sna_pile_radius', text='', icon_value=0, emboss=True)
        row_BDA9D = col_C8797.row(heading='', align=False)
        row_BDA9D.alert = False
        row_BDA9D.enabled = True
        row_BDA9D.active = True
        row_BDA9D.use_property_split = False
        row_BDA9D.use_property_decorate = False
        row_BDA9D.scale_x = 1.0
        row_BDA9D.scale_y = 1.0
        row_BDA9D.alignment = 'Expand'.upper()
        row_BDA9D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_BDA9D.label(text='Depth:', icon_value=0)
        row_BDA9D.prop(bpy.context.scene, 'sna_pile_height', text='', icon_value=0, emboss=True)
        row_3B7C7 = col_C8797.row(heading='', align=False)
        row_3B7C7.alert = False
        row_3B7C7.enabled = True
        row_3B7C7.active = True
        row_3B7C7.use_property_split = False
        row_3B7C7.use_property_decorate = False
        row_3B7C7.scale_x = 1.0
        row_3B7C7.scale_y = 1.0
        row_3B7C7.alignment = 'Expand'.upper()
        row_3B7C7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_3B7C7.label(text='Density:', icon_value=0)
        row_3B7C7.prop(bpy.context.scene, 'sna_pile_resolution', text='', icon_value=0, emboss=True)
        row_FFDB9 = col_C8797.row(heading='', align=False)
        row_FFDB9.alert = False
        row_FFDB9.enabled = True
        row_FFDB9.active = True
        row_FFDB9.use_property_split = False
        row_FFDB9.use_property_decorate = False
        row_FFDB9.scale_x = 1.0
        row_FFDB9.scale_y = 1.0
        row_FFDB9.alignment = 'Expand'.upper()
        row_FFDB9.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_FFDB9.label(text='Objects Scale:', icon_value=0)
        row_FFDB9.prop(bpy.context.scene, 'sna_pile_objectscale', text='', icon_value=0, emboss=True)
        row_62B8C = col_C8797.row(heading='', align=False)
        row_62B8C.alert = False
        row_62B8C.enabled = True
        row_62B8C.active = True
        row_62B8C.use_property_split = False
        row_62B8C.use_property_decorate = False
        row_62B8C.scale_x = 1.0
        row_62B8C.scale_y = 1.0
        row_62B8C.alignment = 'Expand'.upper()
        row_62B8C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_62B8C.label(text='Collection:', icon_value=0)
        row_62B8C.prop(bpy.context.scene, 'sna_pile_collection', text='', icon_value=0, emboss=True)
        op = box_CC4D2.operator('sna.pile_operator_74561', text='Create Pile', icon_value=305, emboss=True, depress=False)
        op = box_CC4D2.operator('sna.volume_operator_c3e8d', text='Estimate Volume', icon_value=289, emboss=True, depress=False)
        for i_23F9C in range(len(lfg['sna_volume_var'])):
            box_CC4D2.label(text=lfg['sna_volume_var'][i_23F9C], icon_value=0)
        row_32120 = box_CC4D2.row(heading='', align=False)
        row_32120.alert = False
        row_32120.enabled = True
        row_32120.active = True
        row_32120.use_property_split = False
        row_32120.use_property_decorate = False
        row_32120.scale_x = 1.0
        row_32120.scale_y = 1.0
        row_32120.alignment = 'Expand'.upper()
        row_32120.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_32120.operator('screen.animation_play', text='Play', icon_value=495, emboss=True, depress=False)
        op = row_32120.operator('screen.animation_play', text='Pause', icon_value=498, emboss=True, depress=False)
        box_84D41 = layout.box()
        box_84D41.alert = False
        box_84D41.enabled = True
        box_84D41.active = True
        box_84D41.use_property_split = False
        box_84D41.use_property_decorate = False
        box_84D41.alignment = 'Expand'.upper()
        box_84D41.scale_x = 1.0
        box_84D41.scale_y = 1.0
        if not True: box_84D41.operator_context = "EXEC_DEFAULT"
        box_84D41.label(text='Utilities:', icon_value=0)
        op = box_84D41.operator('sna.applytransformations_operator_68490', text='Apply Transformations', icon_value=36, emboss=True, depress=False)
        op = box_84D41.operator('sna.joinobjects_operator_37b28', text='Join Objects', icon_value=31, emboss=True, depress=False)


class SNA_OT_Applytransformations_Operator_68490(bpy.types.Operator):
    bl_idname = "sna.applytransformations_operator_68490"
    bl_label = "ApplyTransformations_Operator"
    bl_description = "Applies the transformations of the landfill"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        path_input = None
        # ----- MAIN CODE STARTS ------
        # Find collections that start with "Pile_Objects"
        matching_collections = [coll for coll in bpy.data.collections if coll.name.startswith("Pile_Objects")]
        # Check if 'Pile_Objects' exists in bpy.data.collections
        if matching_collections:
            for pile_collection in matching_collections:
                # Select all objects in the collection
                for obj in pile_collection.objects:
                    obj.select_set(True)
                # Apply all transformations
                bpy.ops.object.visual_transform_apply()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Accept_576D4(bpy.types.Operator, ImportHelper):
    bl_idname = "sna.accept_576d4"
    bl_label = "Accept"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    filter_glob: bpy.props.StringProperty( default='*.png;*.jpg;*.exr', options={'HIDDEN'} )

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_path_input = self.filepath
        return {"FINISHED"}


class SNA_OT_Volume_Operator_C3E8D(bpy.types.Operator):
    bl_idname = "sna.volume_operator_c3e8d"
    bl_label = "Volume_Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        pile_volume = None

        def clean_float(value: float, precision: int = 0) -> str:
            # Avoid scientific notation and strip trailing zeros: 0.000 -> 0.0
            text = f"{value:.{precision}f}"
            index = text.rfind(".")
            if index != -1:
                index += 2
                head, tail = text[:index], text[index:]
                tail = tail.rstrip("0")
                text = head + tail
            return text

        def get_unit(unit_system: str, unit: str):
            # Returns unit length relative to meter and unit symbol
            units = {
                "METRIC": {
                    "KILOMETERS": (1000.0, "km"),
                    "METERS": (1.0, "m"),
                    "CENTIMETERS": (0.01, "cm"),
                    "MILLIMETERS": (0.001, "mm"),
                    "MICROMETERS": (0.000001, "µm"),
                },
                "IMPERIAL": {
                    "MILES": (1609.344, "mi"),
                    "FEET": (0.3048, "\'"),
                    "INCHES": (0.0254, "\""),
                    "THOU": (0.0000254, "thou"),
                },
            }
            try:
                return units[unit_system][unit]
            except KeyError:
                fallback_unit = "CENTIMETERS" if unit_system == "METRIC" else "INCHES"
                return units[unit_system][fallback_unit]

        def bmesh_copy_from_object(obj, transform=True, triangulate=True, apply_modifiers=False):
            """Returns a transformed, triangulated copy of the mesh"""
            assert obj.type == 'MESH'
            if apply_modifiers and obj.modifiers:
                depsgraph = bpy.context.evaluated_depsgraph_get()
                obj_eval = obj.evaluated_get(depsgraph)
                me = obj_eval.to_mesh()
                bm = bmesh.new()
                bm.from_mesh(me)
                obj_eval.to_mesh_clear()
            else:
                me = obj.data
                if obj.mode == 'EDIT':
                    bm_orig = bmesh.from_edit_mesh(me)
                    bm = bm_orig.copy()
                else:
                    bm = bmesh.new()
                    bm.from_mesh(me)
            if transform:
                matrix = obj.matrix_world.copy()
                if not matrix.is_identity:
                    bm.transform(matrix)
                    # Update normals if the matrix has no rotation.
                    matrix.translation.zero()
                    if not matrix.is_identity:
                        bm.normal_update()
            if triangulate:
                bmesh.ops.triangulate(bm, faces=bm.faces)
            return bm

        def Method1():
            obj = bpy.context.active_object
            me = obj.data
            bm = bmesh.new()
            bm.from_mesh(me)
            bm.transform(obj.matrix_world)
            bmesh.ops.triangulate(bm, faces=bm.faces)
            volume = 0
            for f in bm.faces:
                v1 = f.verts[0].co
                v2 = f.verts[1].co
                v3 = f.verts[2].co
                volume += v1.dot(v2.cross(v3)) / 6
            print("Volume:", volume)
            bm.free()

        def Method2():
            scene = bpy.context.scene
            unit = scene.unit_settings
            scale = 1.0 if unit.system == 'NONE' else unit.scale_length
            obj = bpy.context.active_object
            bm = bmesh_copy_from_object(obj, apply_modifiers=True)
            volume = bm.calc_volume()
            bm.free()
            if unit.system == 'NONE':
                volume_fmt = clean_float(volume, 8)
            else:
                length, symbol = get_unit(unit.system, unit.length_unit)
                volume_unit = volume * (scale ** 3.0) / (length ** 3.0)
                volume_str = clean_float(volume_unit, 4)
                volume_fmt = f"{volume_str} {symbol}"
            return volume_unit
        # ----- MAIN CODE STARTS ------
        # Find collections that start with "Pile_Objects"
        matching_collections = [coll for coll in bpy.data.collections if coll.name.startswith("Pile_Objects")]
        pile_volume = [0] * matching_collections.__len__()
        # Check if 'Pile_Objects' exists in bpy.data.collections
        if matching_collections:
            for idx, pile_collection in enumerate(matching_collections):
                # Select all objects in the collection
                for obj in pile_collection.objects:
                    bpy.context.view_layer.objects.active = obj
                # Add up all volumes for each object
                    volume = Method2()
                    pile_volume[idx] += volume
        pile_volume = [f'Pile {idx}:     {element:.4f} m^3' for idx, element in enumerate(pile_volume)]
        lfg['sna_volume_var'] = pile_volume
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Joinobjects_Operator_37B28(bpy.types.Operator):
    bl_idname = "sna.joinobjects_operator_37b28"
    bl_label = "JoinObjects_Operator"
    bl_description = "Joins the objects into a single landfill"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # ----- MAIN CODE STARTS ------
        # Iterate through all collections
        for collection in bpy.data.collections:
            # Check if the collection name starts with "Pile_Objects"
            if collection.name.startswith("Pile_Objects"):
                # Iterate through objects in the collection and select them
                for obj in collection.objects:
                    obj.select_set(True)
        # Check if the 'Landscape' object exists in the scene
        landscape_obj = bpy.context.scene.objects.get('Landscape')
        if bpy.context.selected_objects and landscape_obj:
            # Select the 'Landscape' object
            bpy.context.view_layer.objects.active = landscape_obj
            landscape_obj.select_set(True)
            # Join selected objects with the 'Landscape' object
            bpy.ops.object.join()
            print("Selected objects joined with 'Landscape'.")
        else:
            print("No objects selected or 'Landscape' object not found.")
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Load_Op_D7D67(bpy.types.Operator):
    bl_idname = "sna.load_op_d7d67"
    bl_label = "Load_Op"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        path_input = bpy.context.scene.sna_path_input
        landscape_name = bpy.context.scene.sna_scanned_landscapes
        # Define the file path to the .glb file
        filepath = path_input + "/Landscapes.blend"  # Replace this with the actual file path
        bpy.ops.wm.append(
            filepath=filepath,
            # directory=filepath,
            directory=os.path.join(filepath, 'Collection'),
            filename=landscape_name
        )
        # Get the reference to the collection named "Mountainous"
        collection_to_rename = bpy.data.collections.get(landscape_name)
        # Check if the collection exists and rename it to "Landscape"
        if collection_to_rename:
            collection_to_rename.name = "Landscape"
            # Find the object named "Mountainous" inside the renamed collection
            obj_to_rename = collection_to_rename.objects.get(landscape_name)
            if obj_to_rename:
                # Rename the object to "Landscape"
                obj_to_rename.name = "Landscape"
            else:
                print(f"Object '{landscape_name}' not found inside the collection.")
        else:
            print(f"Collection '{landscape_name}'not found.")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Pile_Operator_74561(bpy.types.Operator):
    bl_idname = "sna.pile_operator_74561"
    bl_label = "Pile_Operator"
    bl_description = "Produces a pile of wast"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        path_input = bpy.context.scene.sna_path_input
        pile_r = bpy.context.scene.sna_pile_radius
        pile_h = bpy.context.scene.sna_pile_height
        pile_density = bpy.context.scene.sna_pile_resolution
        selected_collection = bpy.context.scene.sna_pile_collection
        scale_of_objects = bpy.context.scene.sna_pile_objectscale
        import random
        import math
        import argparse
        # Apply transformations of all Piles

        def apply_transforms():
            # Find collections that start with "Pile_Objects"
            matching_collections = [coll for coll in bpy.data.collections if coll.name.startswith("Pile_Objects")]
            # Check if 'Pile_Objects' exists in bpy.data.collections
            if matching_collections:
                for pile_collection in matching_collections:
                    # Select all objects in the collection
                    for obj in pile_collection.objects:
                        obj.select_set(True)
                    bpy.ops.object.visual_transform_apply()
        # ----- MAIN CODE STARTS ------
        # Apply transformations for previous piles before creating a new one
        apply_transforms()
        # ----- APPEND ALL THE COLLECTIONS -----
        # Get path/names
        collection_layers = bpy.data.scenes["Scene"].view_layers['ViewLayer'].layer_collection.children
        collection_file = path_input + 'collection.blend' # replace with proper collection path
        collection_names = ['Plastics', 'Tyres', 'Metals', 'Woods'] # replace with proper collection name(s)
        bpy.context.scene.frame_set(1)
        # Find and append collections one by one
        filepath = os.path.abspath(collection_file)
        for i in range(len(collection_names)):
            if collection_names[i] not in collection_layers:
                bpy.ops.wm.append(
                    filepath=filepath,
                    # directory=filepath,
                    directory=os.path.join(filepath, 'Collection'),
                    filename=collection_names[i]
                )
                # Hide render and viewport
                collection = bpy.data.collections.get(collection_names[i])
                collection.hide_render = True
                collection.hide_viewport = False  
        # Link with scene_collection and unlink from current collection 
        scene_collection = bpy.context.scene.collection
        for collection in bpy.data.collections:
            for child in collection.children:
                if child.name in collection_names:
                    scene_collection.children.link(bpy.data.collections[child.name])
                    collection.children.unlink(child)
        # ----- CREAT THE EMITTER -----
        # Create a new cone
        bpy.ops.mesh.primitive_cone_add(vertices=32, radius1=pile_r, depth=pile_h)
        # You can adjust the cone's properties, such as location, rotation, and scale
        pile = bpy.data.objects.get("Cone")
        pile.name = "Pile"
        pile.location = (0, 0, 20)
        pile.rotation_euler = (0, 0, 0)
        pile.scale = (1, 1, 1)
        # Add particle system to the active object (to the pile)
        particle_system = pile.modifiers.new(name="PileParticleSystem", type='PARTICLE_SYSTEM')
        # Make pile invisible (and particles visible)
        bpy.data.objects["Pile"].show_instancer_for_viewport = False
        bpy.data.objects["Pile"].show_instancer_for_render = False
        particle_settings = bpy.data.particles.new(name="PileParticleSettings")
        particle_name = particle_settings.name
        bpy.data.particles[particle_name].emit_from = 'VOLUME'
        bpy.data.particles[particle_name].frame_end = 1
        bpy.data.objects["Pile"].particle_systems["PileParticleSystem"].seed = random.randint(1,1000)
        bpy.data.particles[particle_name].distribution = 'GRID'
        bpy.data.particles[particle_name].grid_resolution = pile_density
        bpy.data.particles[particle_name].grid_random = 1
        bpy.data.particles[particle_name].use_rotations = True
        bpy.data.particles[particle_name].rotation_factor_random = 0.5
        bpy.data.particles[particle_name].phase_factor_random = 0.5
        bpy.data.particles[particle_name].render_type = "COLLECTION"
        bpy.data.particles[particle_name].particle_size = scale_of_objects
        bpy.data.particles[particle_name].size_random = 0.25
        bpy.data.particles[particle_name].use_collection_pick_random = True
        bpy.data.particles[particle_name].instance_collection = bpy.data.collections.get(selected_collection)
        # Assign the particle settings to the particle system
        particle_system.particle_system.settings = particle_settings
        # ----- INSTANTIATE OBJECTS -----
        # Create a new collection
        # collection_layers = bpy.data.scenes["Scene"].view_layers['ViewLayer'].layer_collection.children
        # if 'Pile_Objects' not in collection_layers:
        pile_collection = bpy.data.collections.new('Pile_Objects')
        # # Link the new collection to the scene's collection hierarchy
        scene = bpy.context.scene
        scene.collection.children.link(pile_collection)
        # Get the object named "Pile"
        pile = bpy.data.objects.get('Pile')
        bpy.ops.object.duplicates_make_real()
        objs = bpy.context.selected_objects
        # Loop through all objects
        for obj in objs:
            # Loop through all collections the obj is linked to
            for coll in obj.users_collection:
                # Unlink the object
                coll.objects.unlink(obj)
            # Link each object to the target collection
            pile_collection.objects.link(obj)
        bpy.data.objects.remove(pile, do_unlink=True)
        # Set the first object as the active object
        first_object = pile_collection.objects[0]
        bpy.context.view_layer.objects.active = first_object
        # Include all objects in the RigidBodyWorld collection
        bpy.ops.object.collection_link(collection='RigidBodyWorld')
        bpy.ops.rigidbody.objects_add(type='ACTIVE')
        bpy.ops.rigidbody.object_settings_copy()
        # Exclude them from view layer
        collection_layers = bpy.data.scenes["Scene"].view_layers['ViewLayer'].layer_collection.children
        for child in collection_layers:
            if child.name in collection_names:
                child.exclude = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Landscape_Operator_4B2Fb(bpy.types.Operator):
    bl_idname = "sna.landscape_operator_4b2fb"
    bl_label = "Landscape_Operator"
    bl_description = "Produce a random Landscape"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        path_input = bpy.context.scene.sna_path_input
        width = bpy.context.scene.sna_ls_width
        length = bpy.context.scene.sna_ls_length
        height = bpy.context.scene.sna_ls_height
        max_height = bpy.context.scene.sna_ls_maxheight
        min_height = bpy.context.scene.sna_ls_minheight
        texture_file = bpy.context.scene.sna_ls_texture
        import random
        import math
        import argparse

        def prune_suffix(suffix="Landscape", from_='objects'):
            # Prune suffix of Blender objects
            if from_=='objects':
                # Get all the objects in the scene
                objects = bpy.data.objects
                # Iterate through each object
                for obj in objects:
                    # Check if the object name starts with "Landscape"
                    if obj.name.startswith(suffix):
                        # Split the object name by "." and keep the first part (remove the suffix)
                        new_name = obj.name.split(".")[0]
                        # Assign the new name to the object
                        obj.name = new_name
            # Prune suffix of file names inside specified folder
            elif os.path.exists(from_) and os.path.isdir(from_):
                # Iterate through files in the directory
                for filename in os.listdir(from_):
                    base_name, file_extension = os.path.splitext(filename)
                    if base_name.endswith(suffix):
                        # Create the new filename without the suffix
                        new_filename = os.path.join(from_, base_name[:-len(suffix)] + file_extension)
                        # Rename the file
                        os.rename(os.path.join(from_,filename), new_filename)

        def apply_landscape_texture(path_input, texture_file='random'):
            '''
            This function creates a new material and creates the geometry nodes needed inside that material
            Inputs:
                texture_file:  Either 'random' or the name of the folder containing the texture, e.g. 'aerial_grass_rock'
            '''
            # Create a new material
            obj = bpy.data.objects.get("Landscape")
            material = bpy.data.materials.new(name="Landscape_material")
            obj.data.materials.append(material)
            # Switch to node editor and use nodes
            bpy.context.scene.render.engine = 'CYCLES'
            material.use_nodes = True
            tree = material.node_tree
            nodes = tree.nodes
            links = tree.links
            # Access Principled BSDF and Material Output node
            for node in tree.nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        principled_bsdf = node
                    elif node.type == 'OUTPUT_MATERIAL':
                        material_output = node
        # ----- Create Nodes -----
            # Create Normal Map node
            normal_map = nodes.new(type='ShaderNodeNormalMap')
            normal_map.location = (-250, 0)  # Set node location
            # Create Displacement node
            displacement = nodes.new(type='ShaderNodeDisplacement')
            displacement.location = (-250, -150)  # Set node location
            # Create Texture nodes (Base Color, Roughness, Normal, Displacement)
            base_color = nodes.new(type='ShaderNodeTexImage')
            base_color.location = (-700, 300)  # Set node location
            base_color.label = "Base Color"
            roughness = nodes.new(type='ShaderNodeTexImage')
            roughness.location = (-700, 100)  # Set node location
            roughness.label = "Roughness"
            normal = nodes.new(type='ShaderNodeTexImage')
            normal.location = (-700, -100)  # Set node location
            normal.label = "Normal"
            displacement_tex = nodes.new(type='ShaderNodeTexImage')
            displacement_tex.location = (-700, -300)  # Set node location
            displacement_tex.label = "Displacement"
            # Create Texture Coordinate and Mapping nodes
            texture_coordinate = nodes.new(type='ShaderNodeTexCoord')
            texture_coordinate.location = (-1200, 150)  # Set node location
            mapping = nodes.new(type='ShaderNodeMapping')
            mapping.location = (-1000, 150)  # Set node location
        # ----- Connect Nodes -----
            links.new(texture_coordinate.outputs['UV'], mapping.inputs['Vector'])
            links.new(mapping.outputs['Vector'], base_color.inputs['Vector'])
            links.new(mapping.outputs['Vector'], roughness.inputs['Vector'])
            links.new(mapping.outputs['Vector'], normal.inputs['Vector'])
            links.new(mapping.outputs['Vector'], displacement_tex.inputs['Vector'])
            links.new(base_color.outputs['Color'], principled_bsdf.inputs['Base Color'])
            links.new(roughness.outputs['Color'], principled_bsdf.inputs['Roughness'])
            links.new(normal.outputs['Color'], normal_map.inputs['Color'])
            links.new(displacement_tex.outputs['Color'], displacement.inputs['Height'])
            links.new(normal_map.outputs['Normal'], principled_bsdf.inputs['Normal'])
            links.new(displacement.outputs['Displacement'], material_output.inputs['Displacement'])
            # Create frame for Texture Coordinate and Mapping nodes
            frame_mapping = nodes.new(type='NodeFrame')
            frame_mapping.label = 'Mapping'
            frame_mapping.location = (-1300,150)
            # Add Texture Coordinate and Mapping nodes to the frame
            for node in [texture_coordinate, mapping]:
                node.parent = frame_mapping
            # Create a frame for texture nodes
            frame_textures = nodes.new(type='NodeFrame')
            frame_textures.label = 'Textures'
            frame_textures.location = (-900,200)
            # Add nodes to the frame
            for node in [base_color, roughness, displacement_tex]:
                node.parent = frame_textures
            print("Node setup created for 'Landscape'")
        # ----- Load Textures -----
            # Set the texture folder path
            folder_path = path_input + "/Ground_Textures"  # Replace with the actual folder path
            prune_suffix(suffix='_4k.blend', from_=folder_path)
            # List all files in the folder with a .jpg extension (you can modify this for other image formats)
            texture_files = [f for f in os.listdir(folder_path)]
            # Select a random image file
            if texture_files:
                if (texture_file=='random'):
                    terrain_name = random.choice(texture_files)
                    texture_file = terrain_name + '/textures'
                else:
                    terrain_name = texture_file
                    texture_file += '/textures'
            # Combine folder path and selected image file
            textures_path = os.path.join(folder_path, texture_file)
            prune_suffix(suffix='_4k', from_=textures_path)
            # Load textures
            for filename in os.listdir(textures_path):
                base_name, file_extension = os.path.splitext(filename)
                if base_name.endswith('_diff'):
                    base_color.image = bpy.data.images.load(textures_path + '/' + terrain_name + '_diff' + file_extension)
                elif base_name.endswith('_rough'):
                    roughness.image = bpy.data.images.load(textures_path + '/' + terrain_name + '_rough' + file_extension)
                elif base_name.endswith('_nor_gl'):
                    normal.image = bpy.data.images.load(textures_path + '/' + terrain_name + '_nor_gl' + file_extension)
                elif base_name.endswith('_nor_gl'):
                    displacement_tex.image = bpy.data.images.load(textures_path + '/' + terrain_name + '_disp' + file_extension)
                else:
                    print(f'Not needed file named: {filename} detected') 
        # ----- MAIN CODE STARTS -----
        # # Show addons
        # for addon in bpy.context.preferences.addons:
        #     print(addon.module)
        # You must have enabled the A.N.T. Lanscape addon
        # ----- CREATE LANDFILL WITH DEFINED PROPERTIES -----
        # First invoke Landscape
        bpy.ops.mesh.landscape_add('INVOKE_DEFAULT')
        prune_suffix()
        landscape_name = "Landscape"
        landscape_object = bpy.data.objects[landscape_name]
        landscape_object.ant_landscape.subdivision_x = 150
        landscape_object.ant_landscape.subdivision_y = 150
        landscape_object.ant_landscape.mesh_size_x = width
        landscape_object.ant_landscape.mesh_size_y = length
        landscape_object.ant_landscape.noise_size_x = 10
        landscape_object.ant_landscape.noise_size_y = 10
        landscape_object.ant_landscape.noise_size = 1.5
        landscape_object.ant_landscape.random_seed = random.randint(1,1000)
        landscape_object.ant_landscape.height = height
        landscape_object.ant_landscape.maximum = max_height
        landscape_object.ant_landscape.minimum = min_height
        landscape_object.ant_landscape.edge_level = 0.5
        landscape_object.ant_landscape.falloff_x = 10
        landscape_object.ant_landscape.falloff_y = 10
        landscape_object.ant_landscape.strata_type = '1'
        landscape_object.ant_landscape.strata = 10
        # Regenerate landfill but with desired values this time
        bpy.ops.mesh.ant_landscape_regenerate('INVOKE_DEFAULT')
        prune_suffix()
        # Name changed because of regeneration
        landscape_name = "Landscape"
        landscape_object = bpy.data.objects[landscape_name]
        collection = bpy.data.collections.get("Collection")
        # Move Landscape inside Collection
        # for coll in landscape_object.users_collection:
        #     coll.objects.unlink(landscape_object)
        # collection.objects.link(landscape_object)
        # ----- ADD MATERIAL TO LANDSCAPE -----
        apply_landscape_texture(path_input, texture_file)
        # Create UV map using Smart UV Project
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.uv.smart_project(angle_limit=75.0, margin_method='SCALED', island_margin=0.0, area_weight=0.0, correct_aspect=True, scale_to_bounds=True)
        bpy.ops.object.mode_set(mode='OBJECT')
        print("UV map created using Smart UV Project for the object 'Landscape'")
        landscape_object.ant_landscape.land_material = 'Landscape_material'
        # ----- ADD RIGID BODY TO LANDSCAPE -----
        # Select the object
        bpy.context.view_layer.objects.active = landscape_object
        landscape_object.select_set(True)
        # Switch to Object Mode
        bpy.ops.object.mode_set(mode='OBJECT')
        # Add a Rigid Body
        bpy.ops.rigidbody.object_add()
        # Set Rigid Body Type to Passive
        landscape_object.rigid_body.type = 'PASSIVE'
        # Set Friction to 1
        landscape_object.rigid_body.friction = 1.0
        # Set Shape to Mesh
        landscape_object.rigid_body.collision_shape = 'MESH'   
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_path_input = bpy.props.StringProperty(name='Path_Input', description='The path to the LFG folder where all files are located', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_ls_width = bpy.props.FloatProperty(name='LS_width', description='', default=80.0, subtype='NONE', unit='NONE', step=1, precision=3)
    bpy.types.Scene.sna_ls_height = bpy.props.FloatProperty(name='LS_height', description='', default=3.0, subtype='NONE', unit='NONE', step=3, precision=3)
    bpy.types.Scene.sna_ls_length = bpy.props.FloatProperty(name='LS_Length', description='', default=40.0, subtype='NONE', unit='NONE', step=3, precision=3)
    bpy.types.Scene.sna_ls_maxheight = bpy.props.FloatProperty(name='LS_MaxHeight', description='', default=5.0, subtype='NONE', unit='NONE', step=3, precision=3)
    bpy.types.Scene.sna_ls_minheight = bpy.props.FloatProperty(name='LS_MinHeight', description='', default=-2.0, subtype='NONE', unit='NONE', step=3, precision=3)
    bpy.types.Scene.sna_ls_texture = bpy.props.EnumProperty(name='LS_Texture', description='', items=[('random', 'random', 'Choose a texture at random', 0, 0), ('aerial_beach_03', 'aerial_beach_03', '', 0, 1), ('aerial_grass_rock', 'aerial_grass_rock', '', 0, 2), ('aerial_rocks_01', 'aerial_rocks_01', '', 0, 3), ('aerial_mud_1', 'aerial_mud_1', '', 0, 4), ('aerial_rocks_02', 'aerial_rocks_02', '', 0, 5), ('aerial_rocks_04', 'aerial_rocks_04', '', 0, 6), ('aerial_sand', 'aerial_sand', '', 0, 7), ('coast_sand_01', 'coast_sand_01', '', 0, 8), ('coast_sand_rocks_02', 'coast_sand_rocks_02', '', 0, 9), ('dirt_aerial_02', 'dirt_aerial_02', '', 0, 10), ('snow_field_aerial', 'snow_field_aerial', '', 0, 11)])
    bpy.types.Scene.sna_pile_height = bpy.props.FloatProperty(name='Pile_Height', description='', default=23.0, subtype='NONE', unit='NONE', step=3, precision=3)
    bpy.types.Scene.sna_pile_radius = bpy.props.FloatProperty(name='Pile_Radius', description='', default=7.0, subtype='NONE', unit='NONE', step=3, precision=3)
    bpy.types.Scene.sna_pile_resolution = bpy.props.IntProperty(name='Pile_Resolution', description='', default=13, subtype='NONE')
    bpy.types.Scene.sna_pile_collection = bpy.props.StringProperty(name='Pile_Collection', description='The name of the collection of waste objects. The objects will be randomly picked to form a pile', default='Woods', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_pile_objectscale = bpy.props.FloatProperty(name='Pile_ObjectScale', description='', default=1.0, subtype='NONE', unit='NONE', step=3, precision=3)
    bpy.types.Scene.sna_scanned_landscapes = bpy.props.EnumProperty(name='Scanned_Landscapes', description='', items=[('Mountainous', 'Mountainous', '', 0, 0), ('Small_rock', 'Small_rock', '', 0, 1), ('Nature', 'Nature', '', 0, 2)])
    bpy.utils.register_class(SNA_PT_LFG_F666D)
    bpy.utils.register_class(SNA_OT_Applytransformations_Operator_68490)
    bpy.utils.register_class(SNA_OT_Accept_576D4)
    bpy.utils.register_class(SNA_OT_Volume_Operator_C3E8D)
    bpy.utils.register_class(SNA_OT_Joinobjects_Operator_37B28)
    bpy.utils.register_class(SNA_OT_Load_Op_D7D67)
    bpy.utils.register_class(SNA_OT_Pile_Operator_74561)
    bpy.utils.register_class(SNA_OT_Landscape_Operator_4B2Fb)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_scanned_landscapes
    del bpy.types.Scene.sna_pile_objectscale
    del bpy.types.Scene.sna_pile_collection
    del bpy.types.Scene.sna_pile_resolution
    del bpy.types.Scene.sna_pile_radius
    del bpy.types.Scene.sna_pile_height
    del bpy.types.Scene.sna_ls_texture
    del bpy.types.Scene.sna_ls_minheight
    del bpy.types.Scene.sna_ls_maxheight
    del bpy.types.Scene.sna_ls_length
    del bpy.types.Scene.sna_ls_height
    del bpy.types.Scene.sna_ls_width
    del bpy.types.Scene.sna_path_input
    bpy.utils.unregister_class(SNA_PT_LFG_F666D)
    bpy.utils.unregister_class(SNA_OT_Applytransformations_Operator_68490)
    bpy.utils.unregister_class(SNA_OT_Accept_576D4)
    bpy.utils.unregister_class(SNA_OT_Volume_Operator_C3E8D)
    bpy.utils.unregister_class(SNA_OT_Joinobjects_Operator_37B28)
    bpy.utils.unregister_class(SNA_OT_Load_Op_D7D67)
    bpy.utils.unregister_class(SNA_OT_Pile_Operator_74561)
    bpy.utils.unregister_class(SNA_OT_Landscape_Operator_4B2Fb)
